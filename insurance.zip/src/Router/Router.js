import React from 'react'

// ** Router Components
import { BrowserRouter as AppRouter, Route, Switch, Redirect } from 'react-router-dom'
import HeaderCrest from '../components/HeaderCrest'

const Router = () => {
  return (
    <AppRouter basename={"test"}>
      <HeaderCrest />
      <Switch>
        <Route exact path='/' render={() => { return <div>10</div> }} />
        <Route exact path='/1' render={() => { return <div>11</div> }} />
        <Route exact path='/2' render={() => { return <div>12</div> }} />
        <Route exact path='/3' render={() => { return <div>13</div> }} />
      </Switch>
    </AppRouter>
  )
}

export default Router
